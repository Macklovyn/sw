import { Dropzone } from 'dropzone';

const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

Dropzone.options.imagen = {
    dictDefaultMessage: 'Sube tus imágenes aquí',
    acceptedFiles: '.png, .jpg, .jpeg',
    maxFilesize: 5,
    maxFiles: 3, // Allow up to 3 files
    parallelUploads: 3, // You can adjust this based on your needs
    autoProcessQueue: false,
    addRemoveLinks: true,
    dictRemoveFile: 'Borrar Archivo',
    dictMaxFilesExceeded: 'El Límite es 3 Archivos',
    headers: {
        'CSRF-Token': token
    },
    paramName: 'imagen',
    uploadMultiple: true, // Allow multiple files to be selected
    init: function() {
        const dropzone = this;
        const btnPublicar = document.querySelector('#publicar');

        btnPublicar.addEventListener('click', function() {
            dropzone.processQueue();
        });

        dropzone.on('queuecomplete', function() {
            if (dropzone.getActiveFiles().length === 0) {
                window.location.href = '/mis-propiedades';
            }
        });
    }
};
