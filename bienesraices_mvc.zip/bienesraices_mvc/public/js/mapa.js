(function() {

  // Set Initial Coordinates for Mexico City
  const lat = 19.4326;
  const lng = -99.1332;

  // Create Leaflet map
  const mapa = L.map('mapa').setView([lat, lng], 6);

  // Choose a Tile Layer for Mexico (OpenStreetMap)
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(mapa);

  let marker;

  // Utilize Provider and Geocoder
  const geocodeService = L.esri.Geocoding.geocodeService();

  // Create a Marker
  marker = new L.marker([lat, lng], {
      draggable: true,
      autoPan: true
  }).addTo(mapa);

  // Detect the movement of the marker
  marker.on('moveend', function(e) {
      marker = e.target;
      const posicion = marker.getLatLng();
      mapa.panTo(new L.LatLng(posicion.lat, posicion.lng));

      // Obtain street information when releasing the marker
      geocodeService.reverse().latlng(posicion, 13).run(function(error, resultado) {
          marker.bindPopup(resultado.address.LongLabel);

          // Fill the fields
          document.querySelector('.calle').textContent = resultado?.address?.Address ?? '';
          document.querySelector('#calle').value = resultado?.address?.Address ?? '';
          document.querySelector('#lat').value = resultado?.latlng?.lat ?? '';
          document.querySelector('#lng').value = resultado?.latlng?.lng ?? '';
      });
  });

})();
